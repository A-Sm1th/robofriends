export const robots = [
    {
        id: 1,
        name: "Bernard de la Villardière",
        username: "Bernie",
        email: "bernielefou@m6.fr"
    },
    {
        id: 2,
        name: "François-Henri des Maréchaussés",
        username: "s3xy_francois",
        email: "s3xy_francois@francetv.fr"
    },
    {
        id: 3,
        name: "Celine Dion",
        username: "tanerbak_bitch",
        email: "jaimeletabernak@cbc.ca"
    }
]